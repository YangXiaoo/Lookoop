

```python
import pandas as pd
import warnings
warnings.filterwarnings("ignore")
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
train = pd.read_csv(r'C:\Study\github\Lookoops\MachineLearning\kaggle\house_prices\data\train.csv')
test = pd.read_csv(r'C:\Study\github\Lookoops\MachineLearning\kaggle\house_prices\data\test.csv')
```


```python
train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Id</th>
      <th>MSSubClass</th>
      <th>MSZoning</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>Street</th>
      <th>Alley</th>
      <th>LotShape</th>
      <th>LandContour</th>
      <th>Utilities</th>
      <th>...</th>
      <th>PoolArea</th>
      <th>PoolQC</th>
      <th>Fence</th>
      <th>MiscFeature</th>
      <th>MiscVal</th>
      <th>MoSold</th>
      <th>YrSold</th>
      <th>SaleType</th>
      <th>SaleCondition</th>
      <th>SalePrice</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>60</td>
      <td>RL</td>
      <td>65.0</td>
      <td>8450</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>2</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>208500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>20</td>
      <td>RL</td>
      <td>80.0</td>
      <td>9600</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>5</td>
      <td>2007</td>
      <td>WD</td>
      <td>Normal</td>
      <td>181500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>60</td>
      <td>RL</td>
      <td>68.0</td>
      <td>11250</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>9</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>223500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>70</td>
      <td>RL</td>
      <td>60.0</td>
      <td>9550</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>2</td>
      <td>2006</td>
      <td>WD</td>
      <td>Abnorml</td>
      <td>140000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>60</td>
      <td>RL</td>
      <td>84.0</td>
      <td>14260</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>12</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>250000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 81 columns</p>
</div>




```python
train.shape
```




    (1460, 81)




```python
train.dtypes
```




    Id                 int64
    MSSubClass         int64
    MSZoning          object
    LotFrontage      float64
    LotArea            int64
    Street            object
    Alley             object
    LotShape          object
    LandContour       object
    Utilities         object
    LotConfig         object
    LandSlope         object
    Neighborhood      object
    Condition1        object
    Condition2        object
    BldgType          object
    HouseStyle        object
    OverallQual        int64
    OverallCond        int64
    YearBuilt          int64
    YearRemodAdd       int64
    RoofStyle         object
    RoofMatl          object
    Exterior1st       object
    Exterior2nd       object
    MasVnrType        object
    MasVnrArea       float64
    ExterQual         object
    ExterCond         object
    Foundation        object
                      ...   
    BedroomAbvGr       int64
    KitchenAbvGr       int64
    KitchenQual       object
    TotRmsAbvGrd       int64
    Functional        object
    Fireplaces         int64
    FireplaceQu       object
    GarageType        object
    GarageYrBlt      float64
    GarageFinish      object
    GarageCars         int64
    GarageArea         int64
    GarageQual        object
    GarageCond        object
    PavedDrive        object
    WoodDeckSF         int64
    OpenPorchSF        int64
    EnclosedPorch      int64
    3SsnPorch          int64
    ScreenPorch        int64
    PoolArea           int64
    PoolQC            object
    Fence             object
    MiscFeature       object
    MiscVal            int64
    MoSold             int64
    YrSold             int64
    SaleType          object
    SaleCondition     object
    SalePrice          int64
    Length: 81, dtype: object




```python
train['SalePrice'].describe()
```




    count      1460.000000
    mean     180921.195890
    std       79442.502883
    min       34900.000000
    25%      129975.000000
    50%      163000.000000
    75%      214000.000000
    max      755000.000000
    Name: SalePrice, dtype: float64




```python
# 目标变量分布
sns.distplot(train['SalePrice'])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x162395f73c8>




![png](output_6_1.png)



```python
# 皮尔逊相关性
# 可以查看到异常值
sns.jointplot(x='GrLivArea',y='SalePrice',data=train)
```




    <seaborn.axisgrid.JointGrid at 0x1623970fd30>




![png](output_7_1.png)



```python
# 箱线图
sns.boxplot(x="MSZoning", y="SalePrice", data=train)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1623ace1dd8>




![png](output_8_1.png)



```python
# 修建年代
sns.boxplot(x='YearBuilt', y='SalePrice', data=train)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1623ad928d0>




![png](output_9_1.png)



```python
# 同一个属性不同值对于目标值的影响
grouped = train.groupby('OverallQual')
g1 = grouped['SalePrice'].mean().reset_index('OverallQual')
sns.barplot(x='OverallQual',y='SalePrice',data=g1)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1623b7c1080>




![png](output_10_1.png)



```python
corrmatrix = train.corr()
# 绘制热力图，热力图横纵坐标分别是data的index/column,vmax/vmin设置热力图颜色标识上下限，center显示颜色标识中心位置，cmap颜色标识颜色设置
sns.heatmap(corrmatrix,square=True,vmax=1,vmin=-1,center=0.0,cmap='coolwarm')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1623ba66da0>




![png](output_11_1.png)



```python
k=10
# data.nlargest(k, 'target')在data中取‘target'列值排前十的行
# cols为排前十的行的index,在本例中即为与’SalePrice‘相关性最大的前十个特征名
cols = corrmatrix.nlargest(k,'SalePrice')['SalePrice'].index
print(cols) # 打印

cm1 = train[cols].corr()
sns.heatmap(cm1,square=True,annot=True,cmap='RdPu',fmt='.2f',annot_kws={'size':10})
```

    Index(['SalePrice', 'OverallQual', 'GrLivArea', 'GarageCars', 'GarageArea',
           'TotalBsmtSF', '1stFlrSF', 'FullBath', 'TotRmsAbvGrd', 'YearBuilt'],
          dtype='object')
    




    <matplotlib.axes._subplots.AxesSubplot at 0x1623b9b9320>




![png](output_12_2.png)



```python
# 通过热力图选出与目标变量相关性最强的特征
cols_k = ['SalePrice', 'OverallQual', 'GrLivArea', 'GarageCars','TotalBsmtSF', 'FullBath', 'TotRmsAbvGrd', 'YearBuilt']
sns.pairplot(train[cols_k], size=2.5)
```




    <seaborn.axisgrid.PairGrid at 0x1623b75c470>




![png](output_13_1.png)



```python
plt.figure(figsize=(12,6))
plt.scatter(x=train.GrLivArea, y=train.SalePrice)
plt.xlabel("GrLivArea", fontsize=13)
plt.ylabel("SalePrice", fontsize=13)
plt.ylim(0,800000)
plt.show()
```


![png](output_14_0.png)



```python
# 查看训练数据的缺失值
null_value = train.isnull().sum()
sort_null = null_value[null_value > 0].sort_values(ascending=False)
print(sort_null)
```

    PoolQC          1453
    MiscFeature     1406
    Alley           1369
    Fence           1179
    FireplaceQu      690
    LotFrontage      259
    GarageYrBlt       81
    GarageType        81
    GarageFinish      81
    GarageQual        81
    GarageCond        81
    BsmtFinType2      38
    BsmtExposure      38
    BsmtFinType1      37
    BsmtCond          37
    BsmtQual          37
    MasVnrArea         8
    MasVnrType         8
    Electrical         1
    dtype: int64
    


```python
# 测试集的缺失值
test_null = test.isnull().sum()
sort_test_null = test_null[test_null > 0].sort_values(ascending=False)
print(sort_test_null)
```

    PoolQC          1456
    MiscFeature     1408
    Alley           1352
    Fence           1169
    FireplaceQu      730
    LotFrontage      227
    GarageYrBlt       78
    GarageCond        78
    GarageQual        78
    GarageFinish      78
    GarageType        76
    BsmtCond          45
    BsmtExposure      44
    BsmtQual          44
    BsmtFinType1      42
    BsmtFinType2      42
    MasVnrType        16
    MasVnrArea        15
    MSZoning           4
    BsmtFullBath       2
    BsmtHalfBath       2
    Utilities          2
    Functional         2
    Exterior2nd        1
    Exterior1st        1
    SaleType           1
    BsmtFinSF1         1
    BsmtFinSF2         1
    BsmtUnfSF          1
    KitchenQual        1
    GarageCars         1
    GarageArea         1
    TotalBsmtSF        1
    dtype: int64
    


```python
miss_none = ['PoolQC', 'MiscFeature', 'Alley', 'Fence', 'FireplaceQu', 'GarageYrBlt', 'GarageType', 'GarageFinish', 'GarageQual', 'GarageCond', 
            'BsmtFinType2', 'BsmtExposure', 'BsmtFinType1', 'BsmtCond', 'BsmtQual', 'MasVnrType']
miss_zero = ['MasVnrArea', 'BsmtFullBath', 'BsmtHalfBath', 'BsmtFinSF1', 'BsmtFinSF2', 'BsmtUnfSF', 'GarageCars', 'GarageArea', 'TotalBsmtSF']
miss_mode = ['Electrical', 'MSZoning', 'Utilities', 'Exterior2nd', 'Exterior1st', 'SaleType', 'Functional', 'KitchenQual']
miss_special = 'LotFrontage' # 该值为数值类型，不能用0或中值来替代,需要用与其相关性大的数据进行拟合，并且为了减少误差将该值进行分段划分
```


```python
# 将数据结合在一起进行处理，原则上不能这样做，训练数据与测试数据要分离
train.drop(train[(train["GrLivArea"]>4000)&(train["SalePrice"]<300000)].index,inplace=True)
full = pd.concat([train,test], ignore_index=True)
full.drop(['Id'], axis=1, inplace=True)
# full.drop(['SalePrice'], axis=1, inplace=True)
```


```python
for c in miss_none:
    full[c].fillna("None", inplace=True)

for c in miss_zero:
    full[c].fillna(0, inplace=True)
    
for c in miss_mode:
    full[c].fillna(full[c].mode()[0], inplace=True)
```


```python
full.groupby(['Neighborhood'])[['LotFrontage']].agg(['mean','median','count']) # 由Neighborhood分组并计算LotFrontage被分组后在被分组中的平均值中值及数量
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="3" halign="left">LotFrontage</th>
    </tr>
    <tr>
      <th></th>
      <th>mean</th>
      <th>median</th>
      <th>count</th>
    </tr>
    <tr>
      <th>Neighborhood</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Blmngtn</th>
      <td>46.900000</td>
      <td>43.0</td>
      <td>20</td>
    </tr>
    <tr>
      <th>Blueste</th>
      <td>27.300000</td>
      <td>24.0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>BrDale</th>
      <td>21.500000</td>
      <td>21.0</td>
      <td>30</td>
    </tr>
    <tr>
      <th>BrkSide</th>
      <td>55.789474</td>
      <td>51.0</td>
      <td>95</td>
    </tr>
    <tr>
      <th>ClearCr</th>
      <td>88.150000</td>
      <td>80.5</td>
      <td>20</td>
    </tr>
    <tr>
      <th>CollgCr</th>
      <td>71.336364</td>
      <td>70.0</td>
      <td>220</td>
    </tr>
    <tr>
      <th>Crawfor</th>
      <td>69.951807</td>
      <td>70.0</td>
      <td>83</td>
    </tr>
    <tr>
      <th>Edwards</th>
      <td>65.153409</td>
      <td>64.5</td>
      <td>176</td>
    </tr>
    <tr>
      <th>Gilbert</th>
      <td>74.207207</td>
      <td>64.0</td>
      <td>111</td>
    </tr>
    <tr>
      <th>IDOTRR</th>
      <td>62.241379</td>
      <td>60.0</td>
      <td>87</td>
    </tr>
    <tr>
      <th>MeadowV</th>
      <td>25.606061</td>
      <td>21.0</td>
      <td>33</td>
    </tr>
    <tr>
      <th>Mitchel</th>
      <td>75.144444</td>
      <td>74.0</td>
      <td>90</td>
    </tr>
    <tr>
      <th>NAmes</th>
      <td>75.210667</td>
      <td>73.0</td>
      <td>375</td>
    </tr>
    <tr>
      <th>NPkVill</th>
      <td>28.142857</td>
      <td>24.0</td>
      <td>21</td>
    </tr>
    <tr>
      <th>NWAmes</th>
      <td>81.517647</td>
      <td>80.0</td>
      <td>85</td>
    </tr>
    <tr>
      <th>NoRidge</th>
      <td>91.629630</td>
      <td>89.0</td>
      <td>54</td>
    </tr>
    <tr>
      <th>NridgHt</th>
      <td>84.184049</td>
      <td>92.0</td>
      <td>163</td>
    </tr>
    <tr>
      <th>OldTown</th>
      <td>61.777293</td>
      <td>60.0</td>
      <td>229</td>
    </tr>
    <tr>
      <th>SWISU</th>
      <td>59.068182</td>
      <td>60.0</td>
      <td>44</td>
    </tr>
    <tr>
      <th>Sawyer</th>
      <td>74.551020</td>
      <td>72.0</td>
      <td>98</td>
    </tr>
    <tr>
      <th>SawyerW</th>
      <td>70.669811</td>
      <td>67.0</td>
      <td>106</td>
    </tr>
    <tr>
      <th>Somerst</th>
      <td>64.549383</td>
      <td>72.5</td>
      <td>162</td>
    </tr>
    <tr>
      <th>StoneBr</th>
      <td>62.173913</td>
      <td>60.0</td>
      <td>46</td>
    </tr>
    <tr>
      <th>Timber</th>
      <td>81.157895</td>
      <td>82.0</td>
      <td>57</td>
    </tr>
    <tr>
      <th>Veenker</th>
      <td>72.000000</td>
      <td>80.0</td>
      <td>16</td>
    </tr>
  </tbody>
</table>
</div>




```python
full.groupby(['Neighborhood', 'Street'])[['LotFrontage']].agg(['mean','median','count'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th></th>
      <th colspan="3" halign="left">LotFrontage</th>
    </tr>
    <tr>
      <th></th>
      <th></th>
      <th>mean</th>
      <th>median</th>
      <th>count</th>
    </tr>
    <tr>
      <th>Neighborhood</th>
      <th>Street</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Blmngtn</th>
      <th>Pave</th>
      <td>46.900000</td>
      <td>43.0</td>
      <td>20</td>
    </tr>
    <tr>
      <th>Blueste</th>
      <th>Pave</th>
      <td>27.300000</td>
      <td>24.0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>BrDale</th>
      <th>Pave</th>
      <td>21.500000</td>
      <td>21.0</td>
      <td>30</td>
    </tr>
    <tr>
      <th>BrkSide</th>
      <th>Pave</th>
      <td>55.789474</td>
      <td>51.0</td>
      <td>95</td>
    </tr>
    <tr>
      <th>ClearCr</th>
      <th>Pave</th>
      <td>88.150000</td>
      <td>80.5</td>
      <td>20</td>
    </tr>
    <tr>
      <th>CollgCr</th>
      <th>Pave</th>
      <td>71.336364</td>
      <td>70.0</td>
      <td>220</td>
    </tr>
    <tr>
      <th>Crawfor</th>
      <th>Pave</th>
      <td>69.951807</td>
      <td>70.0</td>
      <td>83</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">Edwards</th>
      <th>Grvl</th>
      <td>81.000000</td>
      <td>81.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Pave</th>
      <td>65.062857</td>
      <td>64.0</td>
      <td>175</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">Gilbert</th>
      <th>Grvl</th>
      <td>160.000000</td>
      <td>160.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Pave</th>
      <td>73.427273</td>
      <td>63.5</td>
      <td>110</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">IDOTRR</th>
      <th>Grvl</th>
      <td>84.428571</td>
      <td>66.0</td>
      <td>7</td>
    </tr>
    <tr>
      <th>Pave</th>
      <td>60.300000</td>
      <td>60.0</td>
      <td>80</td>
    </tr>
    <tr>
      <th>MeadowV</th>
      <th>Pave</th>
      <td>25.606061</td>
      <td>21.0</td>
      <td>33</td>
    </tr>
    <tr>
      <th>Mitchel</th>
      <th>Pave</th>
      <td>75.144444</td>
      <td>74.0</td>
      <td>90</td>
    </tr>
    <tr>
      <th>NAmes</th>
      <th>Pave</th>
      <td>75.210667</td>
      <td>73.0</td>
      <td>375</td>
    </tr>
    <tr>
      <th>NPkVill</th>
      <th>Pave</th>
      <td>28.142857</td>
      <td>24.0</td>
      <td>21</td>
    </tr>
    <tr>
      <th>NWAmes</th>
      <th>Pave</th>
      <td>81.517647</td>
      <td>80.0</td>
      <td>85</td>
    </tr>
    <tr>
      <th>NoRidge</th>
      <th>Pave</th>
      <td>91.629630</td>
      <td>89.0</td>
      <td>54</td>
    </tr>
    <tr>
      <th>NridgHt</th>
      <th>Pave</th>
      <td>84.184049</td>
      <td>92.0</td>
      <td>163</td>
    </tr>
    <tr>
      <th>OldTown</th>
      <th>Pave</th>
      <td>61.777293</td>
      <td>60.0</td>
      <td>229</td>
    </tr>
    <tr>
      <th>SWISU</th>
      <th>Pave</th>
      <td>59.068182</td>
      <td>60.0</td>
      <td>44</td>
    </tr>
    <tr>
      <th>Sawyer</th>
      <th>Pave</th>
      <td>74.551020</td>
      <td>72.0</td>
      <td>98</td>
    </tr>
    <tr>
      <th>SawyerW</th>
      <th>Pave</th>
      <td>70.669811</td>
      <td>67.0</td>
      <td>106</td>
    </tr>
    <tr>
      <th>Somerst</th>
      <th>Pave</th>
      <td>64.549383</td>
      <td>72.5</td>
      <td>162</td>
    </tr>
    <tr>
      <th>StoneBr</th>
      <th>Pave</th>
      <td>62.173913</td>
      <td>60.0</td>
      <td>46</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">Timber</th>
      <th>Grvl</th>
      <td>50.000000</td>
      <td>50.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Pave</th>
      <td>81.714286</td>
      <td>82.5</td>
      <td>56</td>
    </tr>
    <tr>
      <th>Veenker</th>
      <th>Pave</th>
      <td>72.000000</td>
      <td>80.0</td>
      <td>16</td>
    </tr>
  </tbody>
</table>
</div>




```python
full['LotFrontage'] = full.groupby(['Neighborhood', 'Street'])[['LotFrontage']].transform(lambda x:x.fillna(x.median()))
```


```python
# 查看是存在缺失值
full_null = full.isnull().sum()
full_null[full_null > 0].sort_values(ascending=False)
```




    SalePrice    1459
    dtype: int64




```python
# 离散数据转换
# 将数值型大小与目标变量无关的数据进行转换
int_to_str = ['MSSubClass', 'YearBuilt', 'YearRemodAdd', 'GarageYrBlt', 'MoSold', 'YrSold' ]
for c in int_to_str:
    full[c] = full[c].astype(str)
```


```python
full.groupby(['MSSubClass'])[['SalePrice']].agg(['mean', 'median'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">SalePrice</th>
    </tr>
    <tr>
      <th></th>
      <th>mean</th>
      <th>median</th>
    </tr>
    <tr>
      <th>MSSubClass</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>120</th>
      <td>200779.080460</td>
      <td>192000.0</td>
    </tr>
    <tr>
      <th>150</th>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>160</th>
      <td>138647.380952</td>
      <td>146000.0</td>
    </tr>
    <tr>
      <th>180</th>
      <td>102300.000000</td>
      <td>88500.0</td>
    </tr>
    <tr>
      <th>190</th>
      <td>129613.333333</td>
      <td>128250.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>185224.811567</td>
      <td>159250.0</td>
    </tr>
    <tr>
      <th>30</th>
      <td>95829.724638</td>
      <td>99900.0</td>
    </tr>
    <tr>
      <th>40</th>
      <td>156125.000000</td>
      <td>142500.0</td>
    </tr>
    <tr>
      <th>45</th>
      <td>108591.666667</td>
      <td>107500.0</td>
    </tr>
    <tr>
      <th>50</th>
      <td>143302.972222</td>
      <td>132000.0</td>
    </tr>
    <tr>
      <th>60</th>
      <td>240403.542088</td>
      <td>216000.0</td>
    </tr>
    <tr>
      <th>70</th>
      <td>166772.416667</td>
      <td>156000.0</td>
    </tr>
    <tr>
      <th>75</th>
      <td>192437.500000</td>
      <td>163500.0</td>
    </tr>
    <tr>
      <th>80</th>
      <td>169736.551724</td>
      <td>166500.0</td>
    </tr>
    <tr>
      <th>85</th>
      <td>147810.000000</td>
      <td>140750.0</td>
    </tr>
    <tr>
      <th>90</th>
      <td>133541.076923</td>
      <td>135980.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
grouped = train.groupby('SaleCondition')
g1 = grouped['SalePrice'].mean().reset_index('SaleCondition')
sns.barplot(x='SaleCondition',y='SalePrice',data=g1)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1624091d128>




![png](output_26_1.png)



```python
grouped = train.groupby('SaleType')
g1 = grouped['SalePrice'].mean().reset_index('SaleType')
sns.barplot(x='SaleType',y='SalePrice',data=g1)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x16240970ef0>




![png](output_27_1.png)



```python
grouped = train.groupby('ExterQual')
g1 = grouped['SalePrice'].mean().reset_index('ExterQual')
sns.barplot(x='ExterQual',y='SalePrice',data=g1)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x16240b13860>




![png](output_28_1.png)



```python
# 评分的变量进行转换
def object_map():
    full['_MSSubClass'] = full.MSSubClass.map({
        '30' : 1, '180' : 1, '45' : 1,
         '160' : 2, '190' : 2, '90' : 2,
        '50' : 3, '85' : 3,
        '40' : 4,  '150' : 4,
        '70' : 5, '80' : 5,
        '20' : 6, '75' : 6,  '120' : 6,
        '60' : 7,
    })
    
    full['_Utilities'] = full.Utilities.map({
        'ELO' : 1,
        'NoSeWa' : 2,
        'NoSewr' : 3,
        'AllPub' : 4,
    })
    
    full['_ExterQual'] = full.ExterQual.map({
       'Ex' : 5,
       'Gd' : 4, 
       'TA' : 3, 
       'Fa' : 2, 
       'Po' : 1, 
    })
    
    full['_ExterCond'] = full.ExterCond.map({
       'Ex' : 5,
       'Gd' : 4, 
       'TA' : 3, 
       'Fa' : 2, 
       'Po' : 1, 
    })
    
    full['_BsmtQual'] = full.BsmtQual.map({
       'Ex' : 6,
       'Gd' : 5, 
       'TA' : 4, 
       'Fa' : 3, 
       'Po' : 2, 
       'None' : 1,
    })
    
    full['_BsmtExposure'] = full.BsmtExposure.map({
       'Gd' : 5,
       'Av' : 4, 
       'Mn' : 3, 
       'No' : 2, 
       'None' : 1, 
    })
    
    full['_BsmtFinType1'] = full.BsmtFinType1.map({
       'GLQ' : 7,
       'ALQ' : 6, 
       'BLQ' : 5, 
       'Rec' : 4, 
       'LwQ' : 3, 
       'Unf' : 2, 
       'None' : 1, 
    })
    
    full['_BsmtFinType2'] = full.BsmtFinType2.map({
       'GLQ' : 7,
       'ALQ' : 6, 
       'BLQ' : 5, 
       'Rec' : 4, 
       'LwQ' : 3, 
       'Unf' : 2, 
       'None' : 1, 
    })
    
    full['_HeatingQC'] = full.HeatingQC.map({
       'Ex' : 5,
       'Gd' : 4, 
       'TA' : 3, 
       'Fa' : 2, 
       'Po' : 1, 
    })
    
    full['_KitchenQual'] = full.KitchenQual.map({
       'Ex' : 5,
       'Gd' : 4, 
       'TA' : 3, 
       'Fa' : 2, 
       'Po' : 1, 
    })
    
    full['_Functional'] = full.Functional.map({
       'Typ' : 8,
       'Min1' : 7, 
       'Min2' : 6, 
       'Mod' : 5, 
       'Maj1' : 4, 
       'Maj2' : 3, 
       'Sev' : 2, 
       'Sal' : 1, 
    })
    
    full['_FireplaceQu'] = full.FireplaceQu.map({
       'Ex' : 6,
       'Gd' : 5, 
       'TA' : 4, 
       'Fa' : 3, 
       'Po' : 2, 
       'None' : 1,
    })
    
    full['_GarageType'] = full.GarageType.map({
       '2Types' : 7,
       'Attchd' : 6, 
       'Basment' : 5, 
       'BuiltIn' : 4, 
       'CarPort' : 3, 
       'Detchd' : 2, 
       'None' : 1, 
    })
    
    full['_GarageFinish'] = full.GarageFinish.map({
       'Fin' : 4,
       'RFn' : 3, 
       'Unf' : 2, 
       'None' : 1, 
    })
    
    full['_GarageQual'] = full.GarageQual.map({
       'Ex' : 6,
       'Gd' : 5, 
       'TA' : 4, 
       'Fa' : 3, 
       'Po' : 2, 
       'None' : 1,
    })
    
    full['_GarageCond'] = full.GarageCond.map({
       'Ex' : 6,
       'Gd' : 5, 
       'TA' : 4, 
       'Fa' : 3, 
       'Po' : 2, 
       'None' : 1,
    })
    
    full['_PavedDrive'] = full.PavedDrive.map({
       'Y' : 3,
       'P' : 2, 
       'N' : 1, 
    })
    
    full['_PoolQC'] = full.PoolQC.map({
       'Ex' : 5,
       'Gd' : 4, 
       'TA' : 3, 
       'Fa' : 2, 
       'None' : 1, 
    })
    
    return None
```


```python
object_map()
```


```python
full.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>1stFlrSF</th>
      <th>2ndFlrSF</th>
      <th>3SsnPorch</th>
      <th>Alley</th>
      <th>BedroomAbvGr</th>
      <th>BldgType</th>
      <th>BsmtCond</th>
      <th>BsmtExposure</th>
      <th>BsmtFinSF1</th>
      <th>BsmtFinSF2</th>
      <th>...</th>
      <th>_HeatingQC</th>
      <th>_KitchenQual</th>
      <th>_Functional</th>
      <th>_FireplaceQu</th>
      <th>_GarageType</th>
      <th>_GarageFinish</th>
      <th>_GarageQual</th>
      <th>_GarageCond</th>
      <th>_PavedDrive</th>
      <th>_PoolQC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>856</td>
      <td>854</td>
      <td>0</td>
      <td>None</td>
      <td>3</td>
      <td>1Fam</td>
      <td>TA</td>
      <td>No</td>
      <td>706.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5</td>
      <td>4</td>
      <td>8</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1262</td>
      <td>0</td>
      <td>0</td>
      <td>None</td>
      <td>3</td>
      <td>1Fam</td>
      <td>TA</td>
      <td>Gd</td>
      <td>978.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5</td>
      <td>3</td>
      <td>8</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>920</td>
      <td>866</td>
      <td>0</td>
      <td>None</td>
      <td>3</td>
      <td>1Fam</td>
      <td>TA</td>
      <td>Mn</td>
      <td>486.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5</td>
      <td>4</td>
      <td>8</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>961</td>
      <td>756</td>
      <td>0</td>
      <td>None</td>
      <td>3</td>
      <td>1Fam</td>
      <td>Gd</td>
      <td>No</td>
      <td>216.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>4</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>2</td>
      <td>2</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1145</td>
      <td>1053</td>
      <td>0</td>
      <td>None</td>
      <td>4</td>
      <td>1Fam</td>
      <td>TA</td>
      <td>Av</td>
      <td>655.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5</td>
      <td>4</td>
      <td>8</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 98 columns</p>
</div>




```python
k=48
corrmatrix = full.corr()
corrmatrix.nlargest(k,'SalePrice')['SalePrice'].index
```




    Index(['SalePrice', 'OverallQual', 'GrLivArea', '_ExterQual', '_KitchenQual',
           'TotalBsmtSF', 'GarageCars', '1stFlrSF', 'GarageArea', '_BsmtQual',
           'FullBath', '_GarageFinish', 'TotRmsAbvGrd', '_FireplaceQu',
           'MasVnrArea', 'Fireplaces', '_MSSubClass', '_HeatingQC', '_GarageType',
           'BsmtFinSF1', '_BsmtExposure', 'LotFrontage', 'WoodDeckSF',
           'OpenPorchSF', '2ndFlrSF', '_BsmtFinType1', 'HalfBath', '_GarageQual',
           'LotArea', '_GarageCond', '_PavedDrive', 'BsmtFullBath', 'BsmtUnfSF',
           'BedroomAbvGr', '_PoolQC', 'ScreenPorch', '_Functional', 'PoolArea',
           '3SsnPorch', '_ExterCond', '_Utilities', '_BsmtFinType2', 'BsmtFinSF2',
           'BsmtHalfBath', 'MiscVal', 'LowQualFinSF', 'OverallCond',
           'EnclosedPorch'],
          dtype='object')




```python
full.drop(['SalePrice'],axis=1,inplace=True)
```


```python
# test
ret = full.select_dtypes(exclude=['object'])
ret.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>1stFlrSF</th>
      <th>2ndFlrSF</th>
      <th>3SsnPorch</th>
      <th>BedroomAbvGr</th>
      <th>BsmtFinSF1</th>
      <th>BsmtFinSF2</th>
      <th>BsmtFullBath</th>
      <th>BsmtHalfBath</th>
      <th>BsmtUnfSF</th>
      <th>EnclosedPorch</th>
      <th>...</th>
      <th>_HeatingQC</th>
      <th>_KitchenQual</th>
      <th>_Functional</th>
      <th>_FireplaceQu</th>
      <th>_GarageType</th>
      <th>_GarageFinish</th>
      <th>_GarageQual</th>
      <th>_GarageCond</th>
      <th>_PavedDrive</th>
      <th>_PoolQC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>856</td>
      <td>854</td>
      <td>0</td>
      <td>3</td>
      <td>706.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>150.0</td>
      <td>0</td>
      <td>...</td>
      <td>5</td>
      <td>4</td>
      <td>8</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1262</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>978.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>284.0</td>
      <td>0</td>
      <td>...</td>
      <td>5</td>
      <td>3</td>
      <td>8</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>920</td>
      <td>866</td>
      <td>0</td>
      <td>3</td>
      <td>486.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>434.0</td>
      <td>0</td>
      <td>...</td>
      <td>5</td>
      <td>4</td>
      <td>8</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>961</td>
      <td>756</td>
      <td>0</td>
      <td>3</td>
      <td>216.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>540.0</td>
      <td>272</td>
      <td>...</td>
      <td>4</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>2</td>
      <td>2</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1145</td>
      <td>1053</td>
      <td>0</td>
      <td>4</td>
      <td>655.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>490.0</td>
      <td>0</td>
      <td>...</td>
      <td>5</td>
      <td>4</td>
      <td>8</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 48 columns</p>
</div>




```python
from sklearn.base import BaseEstimator, TransformerMixin, RegressorMixin, clone
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import RobustScaler, StandardScaler
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline, make_pipeline
from scipy.stats import skew
from sklearn.decomposition import PCA, KernelPCA
from sklearn.preprocessing import Imputer 

import numpy as np
```


```python
class skew_dummies(BaseEstimator, TransformerMixin):
    def __init__(self, skew=0.5):
        self.skew = skew
        
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        X_numeric = X.select_dtypes(exclude=['object']) # 找到数值型数据
        skewness = X_numeric.apply(lambda x:skew(x)) # 计算偏度
        skewness_feature = skewness[abs(skewness) >= self.skew].index
        X[skewness_feature] = np.log1p(X[skewness_feature])
        X = pd.get_dummies(X) # 离散值有大小意义时进行map映射，无大小意义时进行one-hot编码
        
        return X
    
class label_encode(BaseEstimator, TransformerMixin):
    def __init__(self):
        pass
        
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        tool = LabelEncoder()
        X["YearBuilt"] = tool.fit_transform(X["YearBuilt"])
        X["YearRemodAdd"] = tool.fit_transform(X["YearRemodAdd"])
        X["GarageYrBlt"] = tool.fit_transform(X["GarageYrBlt"])
        return X
        
```


```python
class add_feature(BaseEstimator, TransformerMixin):
    def __init__(self):
        pass
        
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        # X['add_house_sale_status'] = X['SaleCondition'] + X['SaleType'] + X['YrSold']
        X['add_house_outside_score'] = X['_PoolQC'] + X['_GarageCond'] + X['_GarageQual']
        X['add_house_inside_score'] = X['_FireplaceQu'] + X['_KitchenQual'] + X['_BsmtFinType2'] + X['_BsmtFinType1'] + X['_BsmtQual']
        X['add_house_based_score'] = X['_HeatingQC'] + X['_Utilities']
        X['add_house_wall_roof_score'] = X['_ExterCond'] + X['_ExterQual']
        
        X["Bsmt"] = X["BsmtFinSF1"] + X["BsmtFinSF2"] + X["BsmtUnfSF"]
        X["Rooms"] = X["FullBath"]+X["TotRmsAbvGrd"]
        X["PorchArea"] = X["OpenPorchSF"]+X["EnclosedPorch"]+X["3SsnPorch"]+X["ScreenPorch"]
        X["TotalPlace"] = X["TotalBsmtSF"] + X["1stFlrSF"] + X["2ndFlrSF"] + X["GarageArea"] + X["OpenPorchSF"]+ X["EnclosedPorch"]+ X["3SsnPorch"]+ X["ScreenPorch"]
        return X
```


```python
full.shape
```




    (2917, 97)




```python
pipe = Pipeline([
    ('label_encode', label_encode()),
    ('skew_dummies', skew_dummies(skew=1)),
    ('add_feature', add_feature()),
])
```


```python
full_pipe = pipe.fit_transform(full)
```


```python
full_pipe.shape
```




    (2917, 357)




```python
full_null = full_pipe.isnull().sum()
full_null[full_null > 0].sort_values(ascending=False)
```




    Series([], dtype: int64)




```python
scaler = RobustScaler()
```


```python
train_index = train.shape[0]
train_x = full_pipe[:train_index]
test_x = full_pipe[train_index:]
train_y = train.SalePrice
```


```python
train_x_scaled = scaler.fit(train_x).transform(train_x)
train_y_scaled = np.log(train_y)
test_x_scaled = scaler.transform(test_x)
```


```python
pca = PCA(n_components=350) # 保留350个特征
```


```python
train_x_pca = pca.fit_transform(train_x_scaled)
test_x_pca = pca.transform(test_x_scaled)
```


```python
train_x_pca.shape, test_x_pca.shape
```




    ((1458, 350), (1459, 350))


